import dearpygui.dearpygui as dpg
import math, random, webbrowser
import threading, time, collections
from pylab import np, plt, mpl
# from numba.experimental import jitclass
# from numba import njit, int32, float64


def _help(message):
    last_item = dpg.last_item()
    group = dpg.add_group(horizontal=True)
    dpg.move_item(last_item, parent=group)
    dpg.capture_next_item(lambda s: dpg.move_item(s, parent=group))
    t = dpg.add_text("(?)", color=[0, 255, 0])
    with dpg.tooltip(t):
        dpg.add_text(message)

def _hyperlink(text, address):
    b = dpg.add_button(label=text, callback=lambda:webbrowser.open(address))
    dpg.bind_item_theme(b, "__demo_hyperlinkTheme")

def _config(sender, keyword, user_data):

    widget_type = dpg.get_item_type(sender)
    items = user_data

    if widget_type == "mvAppItemType::mvRadioButton":
        value = True

    else:
        keyword = dpg.get_item_label(sender)
        value = dpg.get_value(sender)

    if isinstance(user_data, list):
        for item in items:
            dpg.configure_item(item, **{keyword: value})
    else:
        dpg.configure_item(items, **{keyword: value})

def _add_config_options(item, columns, *names, **kwargs):

    if columns == 1:
        if 'before' in kwargs:
            for name in names:
                dpg.add_checkbox(label=name, callback=_config, user_data=item, before=kwargs['before'], default_value=dpg.get_item_configuration(item)[name])
        else:
            for name in names:
                dpg.add_checkbox(label=name, callback=_config, user_data=item, default_value=dpg.get_item_configuration(item)[name])

    else:

        if 'before' in kwargs:
            dpg.push_container_stack(dpg.add_table(header_row=False, before=kwargs['before']))
        else:
            dpg.push_container_stack(dpg.add_table(header_row=False))

        for i in range(columns):
            dpg.add_table_column()

        for i in range(int(len(names)/columns)):

            with dpg.table_row():
                for j in range(columns):
                    dpg.add_checkbox(label=names[i*columns + j],
                                        callback=_config, user_data=item,
                                        default_value=dpg.get_item_configuration(item)[names[i*columns + j]])
        dpg.pop_container_stack()

def _add_config_option(item, default_value, *names):
    dpg.add_radio_button(names, default_value=default_value, callback=_config, user_data=item)

def _hsv_to_rgb(h, s, v):
    if s == 0.0: return (v, v, v)
    i = int(h*6.) # XXX assume int() truncates!
    f = (h*6.)-i; p,q,t = v*(1.-s), v*(1.-s*f), v*(1.-s*(1.-f)); i%=6
    if i == 0: return (255*v, 255*t, 255*p)
    if i == 1: return (255*q, 255*v, 255*p)
    if i == 2: return (255*p, 255*v, 255*t)
    if i == 3: return (255*p, 255*q, 255*v)
    if i == 4: return (255*t, 255*p, 255*v)
    if i == 5: return (255*v, 255*p, 255*q)

def _create_static_textures():

    ## create static textures
    texture_data1 = []
    for i in range(100*100):
        texture_data1.append(255/255)
        texture_data1.append(0)
        texture_data1.append(255/255)
        texture_data1.append(255/255)

    texture_data2 = []
    for i in range(50*50):
        texture_data2.append(255/255)
        texture_data2.append(255/255)
        texture_data2.append(0)
        texture_data2.append(255/255)

    texture_data3 = []
    for row in range(50):
        for column in range(50):
            texture_data3.append(255/255)
            texture_data3.append(0)
            texture_data3.append(0)
            texture_data3.append(255/255)
        for column in range(50):
            texture_data3.append(0)
            texture_data3.append(255/255)
            texture_data3.append(0)
            texture_data3.append(255/255)
    for row in range(50):
        for column in range(50):
            texture_data3.append(0)
            texture_data3.append(0)
            texture_data3.append(255/255)
            texture_data3.append(255/255)
        for column in range(50):
            texture_data3.append(255/255)
            texture_data3.append(255/255)
            texture_data3.append(0)
            texture_data3.append(255/255)

    dpg.add_static_texture(100, 100, texture_data1, parent="__demo_texture_container", tag="__demo_static_texture_1", label="Static Texture 1")
    dpg.add_static_texture(50, 50, texture_data2, parent="__demo_texture_container", tag="__demo_static_texture_2", label="Static Texture 2")
    dpg.add_static_texture(100, 100, texture_data3, parent="__demo_texture_container", tag="__demo_static_texture_3", label="Static Texture 3")

def _create_dynamic_textures():

    ## create dynamic textures
    texture_data1 = []
    for i in range(100*100):
        texture_data1.append(255/255)
        texture_data1.append(0)
        texture_data1.append(255/255)
        texture_data1.append(255/255)

    texture_data2 = []
    for i in range(50*50):
        texture_data2.append(255/255)
        texture_data2.append(255/255)
        texture_data2.append(0)
        texture_data2.append(255/255)

    dpg.add_dynamic_texture(100, 100, texture_data1, parent="__demo_texture_container", tag="__demo_dynamic_texture_1")
    dpg.add_dynamic_texture(50, 50, texture_data2, parent="__demo_texture_container", tag="__demo_dynamic_texture_2")

def _update_dynamic_textures(sender, app_data, user_data):

    new_color = app_data
    new_color[0] = new_color[0]
    new_color[1] = new_color[1]
    new_color[2] = new_color[2]
    new_color[3] = new_color[3]

    if user_data == 1:
        texture_data = []
        for i in range(100*100):
            texture_data.append(new_color[0])
            texture_data.append(new_color[1])
            texture_data.append(new_color[2])
            texture_data.append(new_color[3])
        dpg.set_value("__demo_dynamic_texture_1", texture_data)

    elif user_data == 2:
        texture_data = []
        for i in range(50*50):
            texture_data.append(new_color[0])
            texture_data.append(new_color[1])
            texture_data.append(new_color[2])
            texture_data.append(new_color[3])
        dpg.set_value("__demo_dynamic_texture_2", texture_data)

def _on_demo_close(sender, app_data, user_data):
    dpg.delete_item(sender)
    dpg.delete_item("__demo_texture_container")
    dpg.delete_item("__demo_colormap_registry")
    dpg.delete_item("__demo_hyperlinkTheme")
    dpg.delete_item("__demo_theme_progressbar")
    dpg.delete_item("stock_theme1")
    dpg.delete_item("stock_theme2")
    dpg.delete_item("stock_theme3")
    dpg.delete_item("stock_theme4")
    dpg.delete_item("stem_theme1")
    dpg.delete_item("__demo_keyboard_handler")
    dpg.delete_item("__demo_mouse_handler")
    dpg.delete_item("__demo_filedialog")
    dpg.delete_item("__demo_stage1")
    dpg.delete_item("__demo_popup1")
    dpg.delete_item("__demo_popup2")
    dpg.delete_item("__demo_popup3")
    dpg.delete_item("__demo_item_reg3")
    dpg.delete_item("__demo_item_reg6")
    dpg.delete_item("__demo_item_reg7")
    dpg.delete_item("demoitemregistry")
    for i in range(7):
        dpg.delete_item("__demo_theme"+str(i))
        dpg.delete_item("__demo_theme2_"+str(i))
    for i in range(5):
        dpg.delete_item("__demo_item_reg1_"+str(i))
        dpg.delete_item("__demo_item_reg2_"+str(i))
    for i in range(3):
        dpg.delete_item("__demo_item_reg4_"+str(i))
    for i in range(4):
        dpg.delete_item("__demo_item_reg5_"+str(i))

import struct
import socket

class Listen(object):
    def __init__(self, HOST='192.168.4.50', PORT=5001):   #    192.168.56.1
        # establish socket communication
        self.HOST = HOST
        self.PORT = PORT
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            self.socket.connect((self.HOST, self.PORT))
            print(
                f"Connected to server, HOST: {self.HOST}, PORT: {self.PORT}. ")
        except socket.error as e:
            print(f"Error: {e}")

    def recvall(self, count):
        buf = b''
        while count:
            newbuf = self.socket.recv(count)
            if not newbuf: return None
            buf += newbuf
            count -= len(newbuf)
        return buf


    def recv_data(self):
        # global data_unpacked
        all_data = b''
        # dt_0 = struct.pack('<i', 1)
        # # while True:
        # self.socket.sendall(dt_0)
        all_data = self.recvall(320000)  #self.socket.recv(6400)
        # all_data += data
        # if len(data) < 6400:
        # # either 0 or end of data
        #     break
        data_unpacked = struct.unpack('<80000f', all_data)
            # print(f"Listen: {data_unpacked}")

        # dt_0 = struct.pack('<i', 500)
        # # while True:
        # self.socket.sendall(dt_0)
        return data_unpacked


_Unit_Watch_Mapping = [
    '[A]=POS_CMD_1',
    '[A]=POS_CMD_2',
    '[A]=POS_CMD_3',
    '[A]=POS_CMD_4',
    '[A]=POS_ACT_1',
    '[A]=POS_ACT_2',
    '[A]=POS_ACT_3',
    '[A]=POS_ACT_4',
]
Watch_Mapping = [el[el.find('=')+1:] for el in _Unit_Watch_Mapping] # remove units before "="

global step
step = 0


# @njit(nogil=True)
def realtime_update_data():
    global data_x, data_y, data_y2, data_y3, data_y4, data_y5, data_y6, data_y7, data_y8
    global CONSOLE, step

    CONSOLE.counter = 0
    while True:
        if not CONSOLE._pause:
            data = []
            data = Nile_listen.recv_data()
            for i in range(10000):
                step+=1e-4
                data_x.append(step)
                # data_y.append(data[0])
                # data_y2.append(data[5])
                # data_y3.append(data[1])
                # data_y4.append(data[4])
                # data_y.append( data[i*8+0])#0 4
                # data_y2.append(data[i*8+1])#1 5
                # data_y3.append(data[i*8+2])#2 6
                # data_y4.append(data[i*8+3])#3 7
                # data_y5.append(data[i*8+0])
                # data_y6.append(data[i*8+1])
                # data_y7.append(data[i*8+2])
                # data_y8.append(data[i*8+3])

            data_y.extend(data[:10000])
            data_y2.extend(data[10000:20000])
            data_y3.extend(data[20000:30000])
            data_y4.extend(data[30000:40000])
            data_y5.extend(data[40000:50000])
            data_y6.extend(data[50000:60000])
            data_y7.extend(data[60000:70000])
            data_y8.extend(data[70000:80000])


            # Set the series x and y to the last nsamples (using collections.deque)
            dpg.set_value('tag_realtime_plot1', [list(data_x), list(data_y)])
            dpg.fit_axis_data('tag_x_axis')
            dpg.fit_axis_data('tag_y_axis')

            # Set the series x and y to the last nsamples (using collections.deque)
            dpg.set_value('tag_realtime_plot2', [list(data_x), list(data_y)])
            dpg.fit_axis_data('tag_x_axis')
            dpg.fit_axis_data('tag_y_axis')

            # Set the series x and y to the last nsamples (using collections.deque)
            dpg.set_value('tag_realtime_plot3', [list(data_x), list(data_y2)])
            dpg.fit_axis_data('tag_x_axis1')
            dpg.fit_axis_data('tag_y_axis1')

            # Set the series x and y to the last nsamples (using collections.deque)
            dpg.set_value('tag_realtime_plot4', [list(data_x), list(data_y3)])
            dpg.fit_axis_data('tag_x_axis1')
            dpg.fit_axis_data('tag_y_axis1')

            # Set the series x and y to the last nsamples (using collections.deque)
            dpg.set_value('tag_realtime_plot5', [list(data_x), list(data_y4)])
            dpg.fit_axis_data('tag_x_axis2')
            dpg.fit_axis_data('tag_y_axis2')

            # Set the series x and y to the last nsamples (using collections.deque)
            dpg.set_value('tag_realtime_plot6', [list(data_x), list(data_y4)])
            dpg.fit_axis_data('tag_x_axis2')
            dpg.fit_axis_data('tag_y_axis2')

            time.sleep(0.00001) # limit resource usage
        else:
            time.sleep(0.1)

def show_dem_demo(CONSOLE):

    def _stop_animation(sender, app_data): CONSOLE._pause ^= True

    def _log(sender, app_data, user_data):
        print(f"sender: {sender}, \t app_data: {app_data}, \t user_data: {user_data}")

    # Primary Window
    with dpg.window(label="DEM Primary Window", height=200, width=200, tag="__demo_primary_window"):

        with dpg.tree_node(label="Position Plot 0"):

            with dpg.plot(label='Position Plot 0', height=500, width=-1):
                # optionally create legend
                dpg.add_plot_legend()

                # REQUIRED: create x and y axes, set to auto scale.
                x_axis = dpg.add_plot_axis(dpg.mvXAxis, label='x/s', tag='tag_x_axis')
                y_axis = dpg.add_plot_axis(dpg.mvYAxis, label='y', tag='tag_y_axis')

                # series belong to a y axis. Note the tag name is used in the update function realtime_update_data
                dpg.add_stair_series(x=list(data_x),y=list(data_y),
                                    label='act', parent='tag_y_axis',
                                    tag='tag_realtime_plot1')

                # series belong to a y axis. Note the tag name is used in the update function realtime_update_data
                dpg.add_stair_series(x=list(data_x),y=list(data_y),
                                    label='cmd', parent='tag_y_axis',
                                    tag='tag_realtime_plot2')


        with dpg.tree_node(label="Position Plot 1"):

            with dpg.plot(label='Position Plot 1', height=500, width=-1):
                # optionally create legend
                dpg.add_plot_legend()

                # REQUIRED: create x and y axes, set to auto scale.
                x_axis = dpg.add_plot_axis(dpg.mvXAxis, label='x/s', tag='tag_x_axis1')
                y_axis = dpg.add_plot_axis(dpg.mvYAxis, label='y', tag='tag_y_axis1')

                # series belong to a y axis. Note the tag name is used in the update function realtime_update_data
                dpg.add_stair_series(x=list(data_x),y=list(data_y2),
                                    label='act', parent='tag_y_axis1',
                                    tag='tag_realtime_plot3')

                # series belong to a y axis. Note the tag name is used in the update function realtime_update_data
                dpg.add_stair_series(x=list(data_x),y=list(data_y3),
                                    label='cmd', parent='tag_y_axis1',
                                    tag='tag_realtime_plot4')


        with dpg.tree_node(label="Position Plot 2"):

            with dpg.plot(label='Position Plot 2', height=500, width=-1):
                # optionally create legend
                dpg.add_plot_legend()

                # REQUIRED: create x and y axes, set to auto scale.
                x_axis = dpg.add_plot_axis(dpg.mvXAxis, label='x/s', tag='tag_x_axis2')
                y_axis = dpg.add_plot_axis(dpg.mvYAxis, label='y', tag='tag_y_axis2')

                # series belong to a y axis. Note the tag name is used in the update function realtime_update_data
                dpg.add_stair_series(x=list(data_x),y=list(data_y4),
                                    label='act', parent='tag_y_axis2',
                                    tag='tag_realtime_plot5')

                # series belong to a y axis. Note the tag name is used in the update function realtime_update_data
                dpg.add_stair_series(x=list(data_x),y=list(data_y4),
                                    label='cmd', parent='tag_y_axis2',
                                    tag='tag_realtime_plot6')



        b3 = dpg.add_button(label="Stop/Start Animation", callback=_stop_animation)

    dpg.set_primary_window("__demo_primary_window", True)

    # add a handler registry
    with dpg.handler_registry():
        def _on_press_mvKey_Control(sender, app_data):
            if dpg.is_key_down(dpg.mvKey_A):
                print("Ctrl + A")
        # dpg.add_key_press_handler(dpg.mvKey_Control, callback=_on_press_mvKey_Control)
        dpg.add_key_press_handler(dpg.mvKey_Spacebar, callback=_stop_animation) # , parent="__demo_primary_window"



    dpg.add_texture_registry(label="Demo Texture Container", tag="__demo_texture_container")
    dpg.add_colormap_registry(label="Demo Colormap Registry", tag="__demo_colormap_registry")

    with dpg.theme(tag="__demo_hyperlinkTheme"):
        with dpg.theme_component(dpg.mvButton):
            dpg.add_theme_color(dpg.mvThemeCol_Button, [0, 0, 0, 0])
            dpg.add_theme_color(dpg.mvThemeCol_ButtonActive, [0, 0, 0, 0])
            dpg.add_theme_color(dpg.mvThemeCol_ButtonHovered, [29, 151, 236, 25])
            dpg.add_theme_color(dpg.mvThemeCol_Text, [29, 151, 236])

    _create_static_textures()
    _create_dynamic_textures()

from dataclasses import dataclass
@dataclass
class THE_CONSOLE:
    """ User control over the simulation animation """
    nsamples : int = 200000
    numba__scope_dict: dict = None
    _pause : int = False
    counter: int = 0
    reset : int = False
    bool_exit : int = False
    ii_list: list = None

if __name__ == '__main__':
    Nile_listen = Listen()
    numba__scope_dict = collections.OrderedDict([
    # Y Labels                # Signal Name of Traces
    (r'Torque [Nm]',          ( 'POS_CMD_1', 'POS_ACT_1'              ,)),
    (r'Speed [rpm]',          ( 'POS_CMD_2', 'POS_ACT_2'              ,)),
    (r'$q$-axis current [A]', ( 'POS_CMD_3', 'POS_ACT_3'              ,)),
    (r'$d$-axis current [A]', ( 'POS_CMD_4', 'POS_ACT_4'              ,)),
    ])


    global CONSOLE
    CONSOLE = THE_CONSOLE(numba__scope_dict=numba__scope_dict)
    global data_x, data_y, data_y2, data_y3, data_y4, data_y5, data_y6, data_y7, data_y8
    # Can use collections if you only need the last 100 samples
    data_x = collections.deque([0.0, 0.0], maxlen=CONSOLE.nsamples)
    data_y = collections.deque([0.0, 0.0], maxlen=CONSOLE.nsamples)
    data_y2 = collections.deque([0.0, 0.0], maxlen=CONSOLE.nsamples)
    data_y3 = collections.deque([0.0, 0.0], maxlen=CONSOLE.nsamples)
    data_y4 = collections.deque([0.0, 0.0], maxlen=CONSOLE.nsamples)
    data_y5 = collections.deque([0.0, 0.0], maxlen=CONSOLE.nsamples)
    data_y6 = collections.deque([0.0, 0.0], maxlen=CONSOLE.nsamples)
    data_y7 = collections.deque([0.0, 0.0], maxlen=CONSOLE.nsamples)
    data_y8 = collections.deque([0.0, 0.0], maxlen=CONSOLE.nsamples)

    dpg.create_context()
    dpg.create_viewport(title='RUN_TIME_PLOT', width=1000, height=800)
    show_dem_demo(CONSOLE)
    dpg.setup_dearpygui()
    dpg.show_viewport()
    thread = threading.Thread(target=realtime_update_data)
    thread.daemon = True  # 设置为守护线程
    thread.start()
    dpg.start_dearpygui()
    dpg.destroy_context()

