
#include "acmsimcc.h"


float ACMSimCC::PI_Cal(PI_Reg * r, float err)
{
    float output;
    r->i_state += err * r->Ki;
    if( r->i_state > r->i_limit)
        r->i_state = r->i_limit;
    else if( r->i_state < -r->i_limit)
        r->i_state = -r->i_limit;

    output = r->i_state + err * r->Kp;

    if(output > r->i_limit)
        output = r->i_limit;
    else if(output < -r->i_limit)
        output = -r->i_limit;
    return output;
}

void ACMSimCC::Init() {
  Machine_init();
  acm_init();
  CTRL_init();
  pwm_init();
}


void ACMSimCC::acm_init()
{
    int i;
    for(i=0; i<2; ++i){
        sm.us[i] = 0;
        sm.is[i] = 0;
        sm.us_curr[i] = 0;
        sm.is_curr[i] = 0;
        sm.us_prev[i] = 0;
        sm.is_prev[i] = 0;
    }

    current_index = 0;

    sm.Js = ACM.Js;
    sm.Js_inv = 1./sm.Js;

    sm.R = ACM.R;
    sm.KE = ACM.KE;
    sm.Ld = ACM.Ld;
    sm.Lq = ACM.Lq;

    sm.npp = ACM.npp;
    sm.omg = 0;
}

void ACMSimCC::CTRL_init()
{
    CTRL.timebase = 0.0;

    CTRL.ual = 0.0;
    CTRL.ube = 0.0;

    CTRL.ualQ = 0.0;
    CTRL.ubeQ = 0.0;

    CTRL.R = ACM.R;
    CTRL.KE = ACM.KE;
    CTRL.Ld = ACM.Ld;
    CTRL.Lq = ACM.Lq;

    CTRL.Tload = 0.0;
    CTRL.rpm_cmd = 0.0;

    CTRL.Js = ACM.Js*1.0f;
    CTRL.Js_inv = 1.0 / CTRL.Js;

    CTRL.omg_fb = 0.0;
    CTRL.ial_fb = 0.0;
    CTRL.ibe_fb = 0.0;
    CTRL.psi_mu_al_fb = 0.0;
    CTRL.psi_mu_be_fb = 0.0;

    CTRL.rotor_flux_cmd = 0.0; // id=0 control

    CTRL.omg_ctrl_err = 0.0;
    CTRL.speed_ctrl_err = 0.0;

    CTRL.iMs = 0.0;
    CTRL.iTs = 0.0;

    CTRL.theta_M = 0.0;
    CTRL.cosT = 1.0;
    CTRL.sinT = 0.0;

    CTRL.omega_syn = 0.0;

    CTRL.uMs_cmd = 0.0;
    CTRL.uTs_cmd = 0.0;
    CTRL.iMs_cmd = 0.0;
    CTRL.iTs_cmd = 0.0;

    CTRL.pi_iMs.Kp = wc_torque*CTRL.Ld; // cutoff frequency of 1530 rad/s
    CTRL.pi_iMs.Ki = wc_torque*(CTRL.R*5)*TS;
    CTRL.pi_iMs.i_state = 0.0;
    CTRL.pi_iMs.i_limit = 350.0; //unit: Volt

    CTRL.pi_iTs.Kp = wc_torque*CTRL.Ld;
    CTRL.pi_iTs.Ki = wc_torque*(CTRL.R*5)*TS;
    CTRL.pi_iTs.i_state = 0.0;
    CTRL.pi_iTs.i_limit = 350; // unit: Volt

    //TI speed
    CTRL.pi_speed.Kp = CTRL.pi_iTs.Kp/(CTRL.Ld*sigma*sigma)*sigma*CTRL.Js/(4.0/3.0*ACM.npp*CTRL.KE);
    CTRL.pi_speed.Ki = CTRL.pi_iTs.Kp/(CTRL.Ld*sigma*sigma)*CTRL.pi_speed.Kp*TS;
    CTRL.pi_speed.i_state = 0.0;
    CTRL.pi_speed.i_limit = 8.0f;//[A]
}


float ACMSimCC::lpf(float u)
{
    static float tmp = 0.0f;
    tmp = tmp + (u - tmp)*TS*2000.0f;
    return tmp;
}

void ACMSimCC::control(const float speed_cmd, const float torque_cmd,const float position_cmd)
{
    CTRL.omg_fb = lpf(sm.omg);
    CTRL.ial_fb = IS_C(0);
    CTRL.ibe_fb = IS_C(1);
    CTRL.theta_M = sm.theta_d;

    CTRL.rotor_flux_cmd = 0.0;
    // M-axis current command
    CTRL.iMs_cmd = CTRL.rotor_flux_cmd / CTRL.Ld;

    if (PMSM_CTRL_MODE == Torque_control)
    {
        CTRL.iTs_cmd = torque_cmd;
    }
    else if (PMSM_CTRL_MODE == Velocity_control)
    {
        CTRL.omg_ctrl_err = CTRL.omg_fb - speed_cmd*RPM_2_RAD_PER_SEC;
        CTRL.iTs_cmd = - PI_Cal(&CTRL.pi_speed, CTRL.omg_ctrl_err);
        CTRL.speed_ctrl_err = CTRL.omg_ctrl_err * RAD_PER_SEC_2_RPM;
    }
    else if (PMSM_CTRL_MODE == Position_control)
    {
        CTRL.omg_ctrl_err = CTRL.omg_fb - speed_cmd*RPM_2_RAD_PER_SEC;
        CTRL.iTs_cmd = - PI_Cal(&CTRL.pi_speed, CTRL.omg_ctrl_err);
        CTRL.speed_ctrl_err = CTRL.omg_ctrl_err * RAD_PER_SEC_2_RPM;
    }

    CTRL.cosT = cos(CTRL.theta_M);
    CTRL.sinT = sin(CTRL.theta_M);

    // Measured current in M-T frame
    CTRL.iMs = AB2M(CTRL.ial_fb, CTRL.ibe_fb, CTRL.cosT, CTRL.sinT);
    CTRL.iTs = AB2T(CTRL.ial_fb, CTRL.ibe_fb, CTRL.cosT, CTRL.sinT);

    // Voltage command in M-T frame
    CTRL.uMs_cmd = - PI_Cal(&CTRL.pi_iMs, CTRL.iMs-CTRL.iMs_cmd);
    CTRL.uTs_cmd = - PI_Cal(&CTRL.pi_iTs, CTRL.iTs-CTRL.iTs_cmd);

    if (Vdq_ff_enable)
    {
        CTRL.uMs_cmd += (-CTRL.omg_fb*CTRL.Lq*CTRL.iTs);
        CTRL.uTs_cmd += (CTRL.omg_fb*(CTRL.Ld*CTRL.iMs+CTRL.KE));
    }

    // Voltage command in alpha-beta frame
    CTRL.ual = MT2A(CTRL.uMs_cmd, CTRL.uTs_cmd, CTRL.cosT, CTRL.sinT);
    CTRL.ube = MT2B(CTRL.uMs_cmd, CTRL.uTs_cmd, CTRL.cosT, CTRL.sinT);
}

void ACMSimCC::pwm_init()
{
    gPWM.PRD    = DOWN_FREQ_EXE/2.0;
    gPWM.cnt    = 0;
    gPWM.dir    = 1;
    gPWM.Flag   = 0;

    gPWM.U_alfa = 0;
    gPWM.U_beta = 0;
    gPWM.Ta     = 0;
    gPWM.Tb     = 0;
    gPWM.Tc     = 0;
    gPWM.Va     = 0;
    gPWM.Vb     = 0;
    gPWM.Vc     = 0;
    gPWM.Vmax   = 0;
    gPWM.Vmin   = 0;
    gPWM.Vcomm  = 0;
    gPWM.tmp1   = 0;
    gPWM.tmp2   = 0;
    gPWM.type   = 0;
    gPWM.cmpA   = 0.5*gPWM.PRD;
    gPWM.cmpB   = 0.5*gPWM.PRD;
    gPWM.cmpC   = 0.5*gPWM.PRD;

    gINV.Udc    = 540.0;   //48.0f; //540.0;
}

void  ACMSimCC::dabc_cal()
{
    gPWM.U_alfa = CTRL.ual / (0.63662*gINV.Udc);
    gPWM.U_beta = CTRL.ube / (0.63662*gINV.Udc);

    gPWM.tmp1  =     TEMP1_AI(gPWM.U_alfa);
    gPWM.tmp2  =     TEMP2_AI(gPWM.U_beta);
    gPWM.Va    =     AB2U_AI(gPWM.tmp1);
    gPWM.Vb    =     AB2V_AI(gPWM.tmp1, gPWM.tmp2);
    gPWM.Vc    =     AB2W_AI(gPWM.tmp1, gPWM.tmp2);
   if (gPWM.Va>gPWM.Vb) {gPWM.Vmax=gPWM.Va; gPWM.Vmin=gPWM.Vb;}
   else           {gPWM.Vmax=gPWM.Vb; gPWM.Vmin=gPWM.Va;}
   if (gPWM.Vc>gPWM.Vmax) gPWM.Vmax=gPWM.Vc;
   if (gPWM.Vc<gPWM.Vmin) gPWM.Vmin=gPWM.Vc;
   switch (gPWM.type)
   {
    case 1:
       if (fabs(gPWM.Vmax)-fabs(gPWM.Vmin) > 0)         { gPWM.Vcomm = 0.5-gPWM.Vmax; }
       else                                             { gPWM.Vcomm = -0.5-gPWM.Vmin;}
       break;
    case 2:
       if (fabs(gPWM.Vmax)-fabs(gPWM.Vmin) > 0)         { gPWM.Vcomm = -0.5-gPWM.Vmin;}
       else                                             { gPWM.Vcomm = 0.5-gPWM.Vmax; }
       break;
    default: gPWM.Vcomm = -(gPWM.Vmax+gPWM.Vmin)/2.0;
       break;
   }
   gPWM.Ta = (gPWM.Va+gPWM.Vcomm + 0.5);
   gPWM.Tb = (gPWM.Vb+gPWM.Vcomm + 0.5);
   gPWM.Tc = (gPWM.Vc+gPWM.Vcomm + 0.5);
   gPWM.cmpA = gPWM.Ta*gPWM.PRD;
   gPWM.cmpB = gPWM.Tb*gPWM.PRD;
   gPWM.cmpC = gPWM.Tc*gPWM.PRD;
}

void ACMSimCC::pwm_cnt()
{
    gPWM.Flag   = 0;

    if(gPWM.cnt >= gPWM.PRD)   {gPWM.dir = 0;}
    else if(gPWM.cnt <= 0)     {gPWM.dir = 1; gPWM.Flag   = 1;}
    else  {gPWM.dir = gPWM.dir;}

    if(gPWM.dir == 1)  {gPWM.cnt++;}
    else   {gPWM.cnt--;}

   if (gPWM.cmpA >= gPWM.cnt)
   {
       gINV.iP1 = 1;
       gINV.iP2 = 0;
   }
   else
   {
        gINV.iP1 = 0;
        gINV.iP2 = 1;
   }

   if (gPWM.cmpB >= gPWM.cnt)
   {
       gINV.iP3 = 1;
       gINV.iP4 = 0;
   }
   else
   {
        gINV.iP3 = 0;
        gINV.iP4 = 1;
   }


    if (gPWM.cmpC >= gPWM.cnt)
   {
       gINV.iP5 = 1;
       gINV.iP6 = 0;
   }
   else
   {
        gINV.iP5 = 0;
        gINV.iP6 = 1;
   }

}

void ACMSimCC::Machine_init()
{
    int i;
    for(i=0;i<4;i++){
        ACM.x[i] = 0.0;
    }
    ACM.rpm = 0.0;
    ACM.position_cmd = 0.0;
    ACM.rpm_cmd = 0.0;
    ACM.torque_cmd = 0.0;
    ACM.Tload = 0.0;
    ACM.Tem = 0.0;

    ACM.R  = 0.46;//1.02f; //
    ACM.Ld = 0.0023;//0.00059f;//0.0023;//
    ACM.Lq = 0.0023;//0.00059f;
    ACM.KE = 0.1; //0.041065f / 4.0f;//0.1; //   Vs/(rad/s)
    ACM.L0 = 0.5f*(ACM.Ld + ACM.Lq);
    ACM.L1 = 0.5f*(ACM.Ld - ACM.Lq);

    ACM.Js = 0.00001;//0.0000028f;
    ACM.npp = 3;//4.0f;//3;//
    ACM.mu_m = ACM.npp/ACM.Js;

    ACM.Ts  = MACHINE_TS;

    ACM.id = 0.0;
    ACM.iq = 0.0;

    ACM.ial = 0.0;
    ACM.ibe = 0.0;

    ACM.ia  = 0.0;
    ACM.ib  = 0.0;
    ACM.ic  = 0.0;

    ACM.ud = 0.0;
    ACM.uq = 0.0;

    ACM.ual = 0.0;
    ACM.ube = 0.0;

    ACM.theta_d = 0.0;
}


//state variable : id iq we theta
void ACMSimCC::rK5_dynamics(float t, float *x, float *fx)
{
        fx[0] = (ACM.ud - ACM.R * x[0] + x[2]*ACM.Lq*x[1]) / ACM.Ld;
        fx[1] = (ACM.uq - ACM.R * x[1] - x[2]*ACM.Ld*x[0] - x[2]*ACM.KE) / ACM.Lq;
        // mechanical model
        ACM.Tem = ACM.npp*(x[1]*ACM.KE + (ACM.Ld - ACM.Lq)*x[0]*x[1]);
        fx[2] = (ACM.Tem - ACM.Tload)*ACM.mu_m; // elec. angular rotor speed
        fx[3] = x[2];                           // elec. angular rotor position
}

void ACMSimCC::rK555_Lin(float t, float *x, float hs)
{
    #define NUMBER_OF_STATES 4
    #define NS NUMBER_OF_STATES

    float k1[NS], k2[NS], k3[NS], k4[NS], xk[NS];
    float fx[NS];
    int i;

    rK5_dynamics(t, x, fx); // timer.t,
    for(i=0;i<NS;++i){
        k1[i] = fx[i] * hs;
        xk[i] = x[i] + k1[i]*0.5;
    }

    rK5_dynamics(t, xk, fx); // timer.t+hs/2.,
    for(i=0;i<NS;++i){
        k2[i] = fx[i] * hs;
        xk[i] = x[i] + k2[i]*0.5;
    }

    rK5_dynamics(t, xk, fx); // timer.t+hs/2.,
    for(i=0;i<NS;++i){
        k3[i] = fx[i] * hs;
        xk[i] = x[i] + k3[i];
    }

    rK5_dynamics(t, xk, fx); // timer.t+hs,
    for(i=0;i<NS;++i){
        k4[i] = fx[i] * hs;
        x[i] = x[i] + (k1[i] + 2*(k2[i] + k3[i]) + k4[i])/6.0;
    }
}

int ACMSimCC::machine_simulation()
{
    rK555_Lin(CTRL.timebase, ACM.x, ACM.Ts);
        ACM.theta_d = ACM.x[3];

        if(ACM.theta_d > 2*M_PI){
            ACM.theta_d -= 2*M_PI;
        }else if(ACM.theta_d < 0){
            ACM.theta_d += 2*M_PI;
        }
        ACM.x[3] = ACM.theta_d;
        ACM.id = ACM.x[0];
        ACM.iq = ACM.x[1];
        ACM.ial = MT2A(ACM.id, ACM.iq, cos(ACM.theta_d), sin(ACM.theta_d));
        ACM.ibe = MT2B(ACM.id, ACM.iq, cos(ACM.theta_d), sin(ACM.theta_d));

        ACM.ia  = AB2U_AI(ACM.ial)         ;
        ACM.ib  = AB2V_AI(ACM.ial, ACM.ibe);
        ACM.ic  = AB2W_AI(ACM.ial, ACM.ibe);

        ACM.rpm = ACM.x[2] * 60 / (2 * M_PI * ACM.npp);

        return 1;
}


void ACMSimCC::measurement()
{
    US_C(0) = CTRL.ual;
    US_C(1) = CTRL.ube;
    US_P(0) = US_C(0);
    US_P(1) = US_C(1);

    IS_C(0) = ACM.ial;
    IS_C(1) = ACM.ibe;
    sm.omg = ACM.x[2];
    sm.theta_d = ACM.x[3];
    sm.theta_r = sm.theta_d;
}


void ACMSimCC::inverter_model()
{
    Uint16 iTemp = 0;
    Uint16 iSa = 0;
    Uint16 iSb = 0;
    Uint16 iSc = 0;
    Uint16 iTotal = 0;
    float  Uan     =0;
    float  Ubn     =0;
    float  Ucn     =0;

    gINV.rIa =     AB2U_AI(TEMP1_AI(ACM.ial));
    gINV.rIb =     AB2V_AI(TEMP1_AI(ACM.ial), TEMP2_AI(ACM.ibe));
    gINV.rIc =     AB2W_AI(TEMP1_AI(ACM.ial), TEMP2_AI(ACM.ibe));

    iTemp = 2*gINV.iP1+gINV.iP2;
    switch(iTemp)
    {
        case 2: iSa=1;break;
        case 1: iSa=0;break;
        case 0:
            {
                if(gINV.rIa>=0)
                {
                    iSa=0;
                }
                else
                {
                    iSa=1;
                }
                break;
            }
        case 3: iSa=0;break;
    }

    iTemp =0;
    iTemp = 2*gINV.iP3+gINV.iP4;
    switch(iTemp)
    {
        case 2: iSb=1;break;
        case 1: iSb=0;break;
        case 0:
            {
                if(gINV.rIb>=0)
                {
                    iSb=0;
                }
                else
                {
                    iSb=1;
                }
                break;
            }
        case 3: iSb=0;break;
    }

    iTemp =0;
    iTemp = 2*gINV.iP5+gINV.iP6;
    switch(iTemp)
    {
        case 2: iSc=1;break;
        case 1: iSc=0;break;
        case 0:
            {
                if(gINV.rIc>=0)
                {
                    iSc=0;
                }
                else
                {
                    iSc=1;
                }
                break;
            }
        case 3: iSc=0;break;
    }

    gINV.Uao=iSa*gINV.Udc;
    gINV.Ubo=iSb*gINV.Udc;
    gINV.Uco=iSc*gINV.Udc;

    Uan=(2*gINV.Uao-gINV.Ubo-gINV.Uco)/3;
    Ubn=(2*gINV.Ubo-gINV.Uao-gINV.Uco)/3;
    Ucn=(2*gINV.Uco-gINV.Uao-gINV.Ubo)/3;

    gINV.Ua=Uan;
    gINV.Ub=Ubn;
    gINV.Uc=Ucn;

    ACM.ual = UVW2A_AI(gINV.Ua, gINV.Ub, gINV.Uc);
    ACM.ube = UVW2B_AI(gINV.Ua, gINV.Ub, gINV.Uc);

    if (PWM_Harmonic_Disable)
    {
            ACM.ual = CTRL.ual;//  UVW2A_AI(gINV.Ua, gINV.Ub, gINV.Uc);
            ACM.ube = CTRL.ube;//  UVW2B_AI(gINV.Ua, gINV.Ub, gINV.Uc);
    }
    ACM.ud = AB2M(ACM.ual, ACM.ube, cos(ACM.theta_d), sin(ACM.theta_d));
    ACM.uq = AB2T(ACM.ual, ACM.ube, cos(ACM.theta_d), sin(ACM.theta_d));
}
