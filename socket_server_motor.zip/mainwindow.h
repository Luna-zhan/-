#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTcpSocket>
#include <QTcpServer>
#include <QHostAddress>
#include <QMessageBox>
#include <QByteArray>

#include <QDateTime>
#include <QFileDialog>
#include <QTimer>

#include <QProcess>
#include <acmsimcc.h>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_start_clientButton_clicked();

    void timerout();

    void on_btnSend_clicked();

private:
    void initServer();
    void closeServer();
    void updateState();

private:
    Ui::MainWindow *ui;
    QTcpServer  *server;
    QList<QTcpSocket*> clientList;

    QProcess *process;

    QTimer *timer;
    ACMSimCC acmsimc;
    int sim_loop;
};
#endif // MAINWINDOW_H
