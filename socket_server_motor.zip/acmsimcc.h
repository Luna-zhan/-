#ifndef ACMSIMCC_H
#define ACMSIMCC_H


#include <array>


#include <cmath>
#include <ctime>
#include <fstream>

#define  PWM_Harmonic_Disable    1
#define  Vdq_ff_enable           0
#define  wc_torque               2*M_PI*800
#define  sigma                   50


#define  Torque_control    0
#define  Velocity_control  1
#define  Position_control  2

#define  PMSM_CTRL_MODE     Velocity_control

/* How long should I go? */
#define NUMBER_OF_LINES (500000)

#define MACHINE_TS          1e-4
#define MACHINE_TS_INVERSE  1e4
#define DOWN_FREQ_EXE 1
#define DOWN_FREQ_EXE_INVERSE 1
#define TS (MACHINE_TS*DOWN_FREQ_EXE) //1e-4
#define TS_INVERSE (MACHINE_TS_INVERSE*DOWN_FREQ_EXE_INVERSE)


/* Macro for Part Transformation*/
#define AB2M(A, B, COS, SIN)  ( (A)*COS  + (B)*SIN )
#define AB2T(A, B, COS, SIN)  ( (A)*-SIN + (B)*COS )
#define MT2A(M, T, COS, SIN)  ( (M)*COS - (T)*SIN )
#define MT2B(M, T, COS, SIN)  ( (M)*SIN + (T)*COS )

/* Macro for three-phase Amplitude-invariant Clarke transformation*/
#define UVW2A_AI(U, V, W) ( 0.666666666666667*((U)-0.5*(V)-0.5*(W)) )
#define UVW2B_AI(U, V, W) ( 0.666666666666667*((V)*0.866025403784439-(W)*0.866025403784439) )
//AI : 1
#define TEMP1_AI(A)                     ((float)( (A)*0.5))
#define TEMP2_AI(B)                     ((float)( (B)*0.866025403784439))
#define AB2U_AI(TEMP1_AI)               ((float)  (TEMP1_AI) * 2.0 )
#define AB2V_AI(TEMP1_AI, TEMP2_AI)     ((float) -(TEMP1_AI) + (TEMP2_AI) )
#define AB2W_AI(TEMP1_AI, TEMP2_AI)     ((float) -(TEMP1_AI) - (TEMP2_AI) )


/* Macro for Power-invariant inverse Clarke transformation */
#define UVW2A_PI(U, V, W) ( 0.816496580927726*(U-0.5*V-0.5*W) )
#define UVW2B_PI(U, V, W) ( 0.816496580927726*(V*0.866025403784439-W*0.866025403784439) )
//PI : sqrt(2/3)
#define TEMP1_PI(A)          (0.816496580927726*( (A)*0.5))
#define TEMP2_PI(B)          (0.816496580927726*( (B)*0.866025403784439))
#define AB2U_PI(TEMP1_AI)               (  (TEMP1_AI) * 2.0 )
#define AB2V_PI(TEMP1_AI, TEMP2_AI)     ( -(TEMP1_AI) + (TEMP2_AI) )
#define AB2W_PI(TEMP1_AI, TEMP2_AI)     ( -(TEMP1_AI) - (TEMP2_AI) )


/* General Constants */
#define TRUE True
#define FALSE False
#define True (1)
#define False (0)
#define true 1
#define false 0
#define lTpi                  0.15915494309189535 // 1/(2*pi)
#define TWO_PI_OVER_3         2.0943951023931953
#define SIN_2PI_SLASH_3       0.86602540378443871 // sin(2*pi/3)
#define SIN_DASH_2PI_SLASH_3 -0.86602540378443871 // sin(-2*pi/3)
#define SQRT_2_SLASH_3        0.81649658092772603 // sqrt(2.0/3.0)
#define abs                   use_fabs_instead_or_you_will_regret
#define RAD_PER_SEC_2_RPM (60.0/(2*M_PI*ACM.npp))
#define RPM_2_RAD_PER_SEC ((2*M_PI*ACM.npp)/60.0)
#define M_PI_OVER_180   0.017453292519943295


#define Uint64 unsigned long long
#define Uint32 unsigned long
#define Uint16 unsigned short
#define int64   long long
#define int32   long
#define int16   short

#define BUFF_NUM  (10000)
typedef struct  {
  std::array<float, 8> pose;
} listen_pos;
typedef struct  {
std::array<float, 8*BUFF_NUM> pose;
} listen_ReplyMsg;

class ACMSimCC  {
public:
ACMSimCC(){};
~ACMSimCC(){};

struct ACM_Params_t{
    float x[4];
    float rpm;
    float position_cmd;
    float rpm_cmd;
    float torque_cmd;
    float Tload;
    float Tem;
    float R;
    float Ld;
    float Lq;
    float KE;
    float L0;
    float L1;
    float Js;
    float npp;
    float mu_m;
    float Ts;
    float id;
    float iq;
    float ial;
    float ibe;
    float ia;
    float ib;
    float ic;
    float ud;
    float uq;
    float ual;
    float ube;
    float theta_d;
};

struct  Inverter_t {
    float   Udc;
    Uint16  iP1;
    Uint16  iP2;
    Uint16  iP3;
    Uint16  iP4;
    Uint16  iP5;
    Uint16  iP6;
    float   Ua;
    float   Ub;
    float   Uc;
    float   Uao;
    float   Ubo;
    float   Uco;
    float   rIa;
    float   rIb;
    float   rIc;
};

struct ePWM_t {
   float  cnt;
   float  dir;
   float  PRD;
   float  Flag;

   float  U_alfa;
   float  U_beta;
   float  Ta    ;
   float  Tb    ;
   float  Tc    ;
   float  Va    ;
   float  Vb    ;
   float  Vc    ;
   float  Vmax  ;
   float  Vmin  ;
   float  Vcomm ;
   float  tmp1  ;
   float  tmp2  ;
   Uint16 type  ;
   float  cmpA  ;
   float  cmpB  ;
   float  cmpC  ;
};

struct PI_Reg {
   float   Kp;
   float   Ti;
   float   Ki;      // Ki = Kp/Ti*TS
   float   i_state;
   float   i_limit;
};


struct motor_FOC_control{
    double timebase;

    float ual;
    float ube;
    float ualQ;
    float ubeQ;

    float R;
    float KE;
    float Ld;
    float Lq;

    float Tload;
    float rpm_cmd;

    float Js;
    float Js_inv;

    float omg_fb;
    float ial_fb;
    float ibe_fb;
    float psi_mu_al_fb;
    float psi_mu_be_fb;

    float rotor_flux_cmd;

    float omg_ctrl_err;
    float speed_ctrl_err;

    float iMs;
    float iTs;

    float theta_M;
    float cosT;
    float sinT;

    float omega_syn;

    float uMs_cmd;
    float uTs_cmd;
    float iMs_cmd;
    float iTs_cmd;

     PI_Reg pi_position;
     PI_Reg pi_speed;
     PI_Reg pi_iMs;
     PI_Reg pi_iTs;
};

struct PMSM   {
   float us[2];
   float is[2];
   float us_curr[2];
   float is_curr[2];
   float us_prev[2];
   float is_prev[2];

   float Js;
   float Js_inv;

   float R;
   float KE;
   float Ld;
   float Lq;

   float npp;
   float omg;
   float theta_r;
   float theta_d;
};

PMSM              sm;
motor_FOC_control CTRL;

float   lpf(float u);
void    acm_init();
void    CTRL_init();
void    control(const float speed_cmd, const float torque_cmd, const float position_cmd);
float   PI_Cal( PI_Reg * r, float err);

void    Machine_init();
void    pwm_init();
void    measurement();
void    pwm_cnt();
void    inverter_model();
int     machine_simulation();
void    dabc_cal();
void    rK5_dynamics(float t, float *x, float *fx);
void    rK555_Lin(float t, float *x, float hs);

void    Init();


ACM_Params_t    ACM;
Inverter_t      gINV;
ePWM_t          gPWM;

#define US(X) sm.us[X]
#define IS(X) sm.is[X]
#define US_C(X) sm.us_curr[X]
#define IS_C(X) sm.is_curr[X]
#define US_P(X) sm.us_prev[X]
#define IS_P(X) sm.is_prev[X]


listen_ReplyMsg  g_traj1{0};
listen_ReplyMsg  g_traj2{0};
bool g_traj_flag1 = true;
bool g_traj_flag2 = true;
int current_buffer_index = 0;
int traj_index = 0;

listen_ReplyMsg send_msg;
int current_index;

private:

};

#endif // ACMSIMCC_H
